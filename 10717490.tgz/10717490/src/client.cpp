#include <ros/ros.h>
#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <fstream>
#include <sstream>
#include <string>
#include <ros/package.h>

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

int main(int argc, char** argv) {
    ros::init(argc, argv, "client");

    // Create the action client
    // true causes the client to spin its own thread
    MoveBaseClient ac("move_base", true);

    // Wait for the action server to come up
    while (!ac.waitForServer(ros::Duration(5.0))) {
        ROS_INFO("Waiting for the move_base action server to come up");
    }

    // Get the path to the package and open the CSV file with goals
    std::string package_path = ros::package::getPath("second_project");
    std::string file_path = package_path + "/cfg/waypoints.csv";
    std::ifstream file(file_path);
    if (!file.is_open()) {
        ROS_ERROR("Failed to open goals file: %s", file_path.c_str());
        return -1;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream s(line);
        std::string field;

        std::getline(s, field, ',');
        double goal_x = std::stod(field);

        std::getline(s, field, ',');
        double goal_y = std::stod(field);

        std::getline(s, field, ',');
        double goal_theta = std::stod(field);

        move_base_msgs::MoveBaseGoal goal;

        // Set up the frame parameters
        goal.target_pose.header.frame_id = "map";
        goal.target_pose.header.stamp = ros::Time::now();

        // Define a position and orientation for the robot to reach
        goal.target_pose.pose.position.x = goal_x;
        goal.target_pose.pose.position.y = goal_y;
        goal.target_pose.pose.orientation.w = cos(goal_theta / 2.0);
        goal.target_pose.pose.orientation.z = sin(goal_theta / 2.0);

        ROS_INFO("Sending goal: x = %f, y = %f, theta = %f", goal_x, goal_y, goal_theta);
        ac.sendGoal(goal);

        // Wait for the result
        ac.waitForResult();

        if (ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
            ROS_INFO("The base moved to the goal");
        else
            ROS_INFO("The base failed to move to the goal for some reason");
    }

    file.close();
    return 0;
}


