#include "ros/ros.h"
#include <nav_msgs/Odometry.h>
#include <tf/transform_broadcaster.h>

class tf_sub_pub{
public:
  	tf_sub_pub():n_private("~") {
     n_private.getParam("child_frame", child_frame);
     n_private.getParam("root_frame", root_frame);

     ros::NodeHandle nh_global;
  	 sub = nh_global.subscribe("input_odom", 10, &tf_sub_pub::callback, this);
}


void callback(const nav_msgs::Odometry::ConstPtr& msg){
  tf::Transform transform;
  transform.setOrigin( tf::Vector3(msg->pose.pose.position.x, msg->pose.pose.position.y, msg->pose.pose.position.z) );
  tf::Quaternion q(msg->pose.pose.orientation.x, msg->pose.pose.orientation.y, msg->pose.pose.orientation.z, msg->pose.pose.orientation.w);
  transform.setRotation(q);

  br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), root_frame, child_frame));
}

private: 
  ros::NodeHandle n_private;
  tf::TransformBroadcaster br;
  ros::Subscriber sub;
  std::string child_frame, root_frame;
};


int main(int argc, char **argv){
 ros::init(argc, argv, "odom_to_tf");
 tf_sub_pub my_tf_sub_bub;
 ros::spin();
 return 0;
}

